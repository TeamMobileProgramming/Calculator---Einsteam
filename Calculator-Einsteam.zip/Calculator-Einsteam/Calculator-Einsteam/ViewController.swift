//
//  ViewController.swift
//  Calculator-Einsteam
//
//  Created by Romit Bhatia on 4/26/16.
//  Copyright © 2016 Einsteam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var entering = false
    var num1 = 0.0
    var num2 = 0.0
    var opr = ""
    
    @IBOutlet var txtview: UITextField!
    @IBOutlet var button1: UIButton!
    
    @IBOutlet var button2: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func onButton1(sender: UIButton) {
        var num = sender.currentTitle
        if entering {
            txtview.text = txtview.text! + num!
        }
        else {
            txtview.text = num
            entering = true
        }
    }
    
    @IBAction func onOperator(sender: UIButton) {
        entering = false
        num1 = Double(txtview.text!)!
        opr = sender.currentTitle!
    }
    
    @IBAction func onClear(sender: UIButton) {
        txtview.text = ""
        num1 = 0.0
        num2 = 0.0
    }
    @IBAction func onequal(sender: UIButton) {
        entering = false
        var res = 0.0
        num2 = Double(txtview.text!)!
        switch opr {
        case "+" : res = Double(num1 + num2)
                    txtview.text = String(res)
        case "-" : res = Double(num1 - num2)
                    txtview.text = String(res)
        case "*" : res = Double(num1 * num2)
                    txtview.text = String(res)
        case "/" : res = Double(num1 / num2)
                    txtview.text = String(res)
        default  : res = 0.0
                    txtview.text = String(res)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

